
import axiosInstance from '../ApiClient';

export const signup = async (userData) => {
  try {
    const response = await axiosInstance.post('/register', userData); 
    return response.data;
  } catch (error) {
    // You can customize error handling here
    throw error.response?.data || { message: 'Signup failed' };
  }
};