import React from 'react'

const Login = () => {
  return (
    <div>
      login
    </div>
  )
}

export default Login
