import React from 'react'

const HomePage = () => {
  return (
    <div>
      home
    </div>
  )
}

export default HomePage
